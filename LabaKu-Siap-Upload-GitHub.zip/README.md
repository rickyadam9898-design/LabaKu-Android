# LabaKu — Aplikasi Hitung Laba Penjualan

Project Android native Java. Data transaksi disimpan secara lokal di perangkat menggunakan SharedPreferences. Aplikasi tidak meminta izin internet.

## Cara unggah ke GitHub

1. Buat repository baru di GitHub, misalnya `LabaKu-Android`.
2. Ekstrak ZIP ini di perangkat/komputer.
3. Unggah **isi folder hasil ekstrak** ke halaman utama repository (bukan folder pembungkusnya).
4. Pastikan file workflow ikut terunggah di lokasi persis `.github/workflows/build-apk.yml`.
5. Buka tab **Actions**. Pilih **Build APK** lalu tekan **Run workflow**. Jika tab Actions belum terlihat, buka Settings → Actions → General dan izinkan Actions.
6. Setelah proses berstatus hijau/success, buka hasil workflow tersebut. Di bagian Artifacts unduh `LabaKu-debug-apk`.
7. Ekstrak file artifact ZIP, lalu instal `app-debug.apk` di Android.

## Jika folder `.github` tidak terlihat saat upload lewat HP

Beberapa aplikasi pengelola file menyembunyikan folder yang diawali titik. Aktifkan opsi **Tampilkan file tersembunyi** sebelum memilih berkas. Jika GitHub web di HP tidak bisa mengunggah folder tersembunyi, buat file secara manual di GitHub dengan path `.github/workflows/build-apk.yml`, lalu salin isi workflow dari file tersebut.

## Fitur

- Menghitung omzet, total modal, laba bersih, dan margin.
- Input nama barang, harga modal, harga jual, jumlah, dan biaya tambahan.
- Menyimpan riwayat transaksi di perangkat.
- Melihat ringkasan total transaksi.

## Rumus

Laba bersih = (harga jual × jumlah) − (harga modal × jumlah) − biaya tambahan.

Margin = laba bersih ÷ omzet × 100%.

## Persyaratan build

- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Android SDK platform 35 (diunduh otomatis oleh runner Android build bila diperlukan)

Catatan: ZIP ini adalah source project, bukan APK yang sudah dikompilasi.
