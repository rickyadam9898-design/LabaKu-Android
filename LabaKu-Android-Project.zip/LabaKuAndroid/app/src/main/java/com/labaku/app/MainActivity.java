package com.labaku.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final int GREEN = Color.rgb(12, 112, 85);
    private final int DARK = Color.rgb(8, 53, 45);
    private final int BG = Color.rgb(245, 248, 247);
    private EditText name, cost, price, qty, extra;
    private TextView result, summary;
    private LinearLayout historyBox;
    private SharedPreferences prefs;
    private double lastProfit = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("labaku_local", MODE_PRIVATE);
        showHome();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private String rupiah(double n) {
        NumberFormat f = NumberFormat.getNumberInstance(new Locale("id","ID"));
        f.setMaximumFractionDigits(0);
        return "Rp " + f.format(n);
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(14), dp(18), dp(18)); l.setBackgroundColor(BG); return l;
    }
    private void addField(LinearLayout parent, String label, EditText field) {
        parent.addView(text(label, 13, DARK, true));
        field.setSingleLine(true); field.setTextSize(16); field.setPadding(dp(12),dp(12),dp(12),dp(12));
        field.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.LTGRAY));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(12);
        parent.addView(field,p);
    }
    private EditText input(String hint, int type) {
        EditText e = new EditText(this); e.setHint(hint); e.setInputType(type); return e;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN));
        return b;
    }
    private double number(EditText e) {
        try { return Double.parseDouble(e.getText().toString().replace(".","").replace(",","").trim()); }
        catch(Exception ex) { return 0; }
    }
    private void showHome() {
        LinearLayout page = column();
        TextView header = text("LabaKu", 28, Color.WHITE, true);
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(18),dp(20),dp(18),dp(20)); top.setBackgroundColor(DARK);
        top.addView(header); top.addView(text("Kalkulator laba penjualan",14,Color.rgb(210,235,226),false));
        page.addView(top, new LinearLayout.LayoutParams(-1,-2));

        summary = text(summaryText(), 15, DARK, true);
        summary.setPadding(dp(14),dp(14),dp(14),dp(14));
        summary.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(14); sp.bottomMargin=dp(16);
        page.addView(summary,sp);

        page.addView(text("Input penjualan",19,DARK,true));
        name = input("Contoh: Baju", android.text.InputType.TYPE_CLASS_TEXT);
        cost = input("Harga modal per barang (Rp)", android.text.InputType.TYPE_CLASS_NUMBER);
        price = input("Harga jual per barang (Rp)", android.text.InputType.TYPE_CLASS_NUMBER);
        qty = input("Jumlah terjual", android.text.InputType.TYPE_CLASS_NUMBER);
        extra = input("Biaya tambahan total (Rp), isi 0 jika tidak ada", android.text.InputType.TYPE_CLASS_NUMBER);
        addField(page,"Nama barang",name); addField(page,"Harga modal satuan",cost);
        addField(page,"Harga jual satuan",price); addField(page,"Jumlah terjual",qty);
        addField(page,"Biaya tambahan",extra);

        result = text("Hasil perhitungan akan tampil di sini.",16,DARK,true);
        result.setPadding(dp(14),dp(14),dp(14),dp(14)); result.setBackgroundColor(Color.WHITE);
        page.addView(result);
        Button calc = button("Hitung laba");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2); bp.topMargin=dp(12);
        page.addView(calc,bp); calc.setOnClickListener(v -> calculate(false));
        Button save = button("Simpan transaksi");
        page.addView(save); save.setOnClickListener(v -> calculate(true));
        Button history = button("Lihat riwayat transaksi");
        page.addView(history); history.setOnClickListener(v -> showHistory());

        ScrollView scroll = new ScrollView(this); scroll.addView(page); setContentView(scroll);
    }
    private void calculate(boolean save) {
        double c=number(cost), p=number(price), q=number(qty), x=number(extra);
        if(name.getText().toString().trim().isEmpty() || c<=0 || p<=0 || q<=0 || x<0) {
            Toast.makeText(this,"Lengkapi nama, modal, harga jual, dan jumlah dengan benar.",Toast.LENGTH_LONG).show(); return;
        }
        double omzet=p*q, modal=c*q, profit=omzet-modal-x;
        lastProfit=profit;
        double margin=omzet==0?0:(profit/omzet)*100;
        result.setText("OMZET  " + rupiah(omzet) + "\nTOTAL MODAL  " + rupiah(modal) +
                "\nBIAYA TAMBAHAN  " + rupiah(x) + "\nLABA BERSIH  " + rupiah(profit) +
                "\nMargin laba: " + String.format(Locale.US,"%.2f",margin) + "%");
        if(save) {
            try {
                JSONArray a = new JSONArray(prefs.getString("transactions","[]"));
                JSONObject o = new JSONObject();
                o.put("name",name.getText().toString().trim()); o.put("cost",c); o.put("price",p);
                o.put("qty",q); o.put("extra",x); o.put("omzet",omzet); o.put("profit",profit);
                o.put("date",new SimpleDateFormat("dd-MM-yyyy HH:mm",new Locale("id","ID")).format(new Date()));
                a.put(o); prefs.edit().putString("transactions",a.toString()).apply();
                summary.setText(summaryText());
                Toast.makeText(this,"Transaksi berhasil disimpan di HP.",Toast.LENGTH_SHORT).show();
            } catch(Exception e) { Toast.makeText(this,"Gagal menyimpan transaksi.",Toast.LENGTH_SHORT).show(); }
        }
    }
    private String summaryText() {
        try {
            JSONArray a=new JSONArray(prefs.getString("transactions","[]"));
            double sales=0, profit=0;
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);sales+=o.optDouble("omzet");profit+=o.optDouble("profit");}
            return "RINGKASAN SEMUA TRANSAKSI\nOmzet: "+rupiah(sales)+"\nTotal laba bersih: "+rupiah(profit)+"\nJumlah transaksi: "+a.length();
        } catch(Exception e){return "Belum ada transaksi tersimpan.";}
    }
    private void showHistory() {
        LinearLayout page=column();
        page.addView(text("Riwayat transaksi",24,DARK,true));
        TextView total=text(summaryText(),15,DARK,true); total.setPadding(0,dp(10),0,dp(14)); page.addView(total);
        historyBox=new LinearLayout(this); historyBox.setOrientation(LinearLayout.VERTICAL); page.addView(historyBox);
        try {
            JSONArray a=new JSONArray(prefs.getString("transactions","[]"));
            if(a.length()==0) historyBox.addView(text("Belum ada transaksi.",15,DARK,false));
            for(int i=a.length()-1;i>=0;i--){
                JSONObject o=a.getJSONObject(i);
                LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12),dp(12),dp(12),dp(12)); card.setBackgroundColor(Color.WHITE);
                LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.bottomMargin=dp(8);
                historyBox.addView(card,cp);
                card.addView(text(o.optString("name"),17,DARK,true));
                card.addView(text(o.optString("date"),12,Color.GRAY,false));
                card.addView(text("Jumlah: "+(int)o.optDouble("qty")+" | Omzet: "+rupiah(o.optDouble("omzet")),14,DARK,false));
                card.addView(text("Laba bersih: "+rupiah(o.optDouble("profit")),15,o.optDouble("profit")>=0?GREEN:Color.RED,true));
            }
        }catch(Exception ignored){}
        Button del=button("Hapus semua riwayat");
        page.addView(del); del.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Hapus riwayat?").setMessage("Semua transaksi tersimpan akan dihapus.")
                .setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{
                    prefs.edit().remove("transactions").apply(); showHistory();
                }).show());
        Button back=button("Kembali"); page.addView(back); back.setOnClickListener(v->showHome());
        ScrollView sc=new ScrollView(this); sc.addView(page); setContentView(sc);
    }
}
