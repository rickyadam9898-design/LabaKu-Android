# LabaKu – Android

Aplikasi kalkulator laba penjualan offline. Data transaksi disimpan lokal di SharedPreferences pada perangkat.

## Fitur
- Hitung omzet, total modal, biaya tambahan, laba bersih, dan margin.
- Simpan transaksi dan lihat ringkasan seluruh transaksi.
- Riwayat transaksi tersimpan di perangkat; hapus riwayat tersedia.
- Tidak memerlukan koneksi internet dan tidak meminta izin jaringan.

## Membuat APK
Proyek ini berisi source code Android. APK belum dikompilasi di lingkungan ini karena Android SDK/Gradle tidak tersedia.

Cara paling mudah:
1. Buat repository GitHub baru dan unggah seluruh isi folder proyek ini.
2. Buka tab **Actions** dan jalankan workflow **Build APK**.
3. Setelah selesai, buka hasil workflow dan unduh artifact `LabaKu-debug-apk`.
4. Ekstrak ZIP artifact, lalu instal `app-debug.apk` di Android. Jika diminta, izinkan instalasi dari sumber tersebut.

Atau buka folder ini dengan Android Studio, tunggu Gradle sync, lalu pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Perhitungan
Laba bersih = (harga jual × jumlah) − (harga modal × jumlah) − biaya tambahan.
Margin laba = laba bersih ÷ omzet × 100%.
